package com.Allservlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/Addcustomer")
public class Addcustomer extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		response.setContentType("Text/html");
		PrintWriter out = response.getWriter();
				
		String FlightNo = request.getParameter("FlightNo");	
		out.print("<h3>Enter passanger details</h3>");
		out.print("<form action='Bookit' method='post'>");
		out.print("<table border='1'><tr>");
		out.print("<td><h4>Fight No :"+FlightNo+ "</h4></td></tr><tr>");
		out.print("<td><label>passanger Name</label></td><td> <input type='Text'name='passangerName'required='required'size='50'></td></tr>");
		out.print("<td><label>gender</label></td><td> <input type='Text'name='gender'required='required'size='4'></td></tr>");
		out.print("<td><label>Email</label></td><td> <input type='email'name='email'required='required'size='50'></td></tr>");
		out.print("<td><label>Ticketstatus</label></td><td> <input type='Text'name='Ticketstatus'required='required'size='50'></td></tr>");
		out.print("<td><label>FlightNo</label></td><td> <input type='Text'disabled name='FlightNo'value="+FlightNo+".");
		out.print("</td></tr>");
		out.print("<td><button type='submit' value=Bookit'>Submit</button></td></tr>");
		out.print("</form>");
		out.print("</table>");
		
			
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
