package com.Allservlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.Entities.Flightdetails;
import com.HibernateConnection.FactoryProvider;


@WebServlet("/Addnewflight")
public class Addnewflight extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		
			response.setContentType("Text/html");
			PrintWriter out = response.getWriter();
			
			String FlightName = request.getParameter("FlightName");
			String FromCity = request.getParameter("FromCity");
			String ToCity = request.getParameter("ToCity");
			String TravelDate = request.getParameter("TravelDate");
			String Fair = request.getParameter("Fair");
			
//			converting string date to Data object
//			SimpleDateFormat df = new SimpleDateFormat("mm/dd/yyyy");
//			Date startDate= null;
//			try {
//				startDate = df.parse(TravelDate);
//			} catch (ParseException e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			}
			
			//converting string date to Double
			double Fair1 = Double.parseDouble(Fair); 
			
			
			
			//Createing user Object
			Flightdetails flight = new Flightdetails(FlightName,FromCity,ToCity,TravelDate,Fair1);

			// write code to Add data to database
			Session s = FactoryProvider.getFactory().openSession(); 
			Transaction Tx = s.beginTransaction();
			s.save(flight);
			Tx.commit();
			s.close(); 
			response.setContentType("Text/html"); 
			out.print("New user "+ flight +" added sucessfully");
			System.out.println("added sucessfully");
			
				
		}
		
	

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
