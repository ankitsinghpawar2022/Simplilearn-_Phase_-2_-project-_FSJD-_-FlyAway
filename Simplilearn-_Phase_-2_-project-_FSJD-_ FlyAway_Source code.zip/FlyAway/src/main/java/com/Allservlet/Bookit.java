package com.Allservlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.Entities.Bookings;
import com.Entities.Flightdetails;
import com.HibernateConnection.FactoryProvider;

@WebServlet("/Bookit")
public class Bookit extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		response.setContentType("Text/html");
		PrintWriter out = response.getWriter();
		
		String FlightNo = request.getParameter("FlightNo");
		String passangerName = request.getParameter("passangerName");
		String gender = request.getParameter("gender");
		String email = request.getParameter("email");
		String Ticketstatus = request.getParameter("Ticketstatus");
			
		out.println(FlightNo);
		out.println(passangerName);
		out.println(gender);
		out.println(email);
		out.println(Ticketstatus);
		out.println("***************");
		
		//converting string date to Double
		//int FlightNo1 = Integer.parseInt(FlightNo);
		
		//Createing user Object
		Bookings B1 = new Bookings(passangerName,gender,email,Ticketstatus,new Date());

		// write code to Add data to database
		Session s = FactoryProvider.getFactory().openSession(); 
		Transaction Tx = s.beginTransaction();
		s.save(B1);
		Tx.commit();
		s.close(); 
		response.setContentType("Text/html"); 
		out.print("New user "+ B1 +" added sucessfully");
		System.out.println("added sucessfully");
				
	}	
	
		
	

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
