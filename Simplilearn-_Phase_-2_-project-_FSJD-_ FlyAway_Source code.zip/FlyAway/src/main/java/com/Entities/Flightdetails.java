package com.Entities;

import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;


@Entity
public class Flightdetails {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private int FlightNo;
	private String FlightName;
	private String FromCity;
	private String ToCity;
	private String TravelDate;
	private double Fair;
	
	@OneToMany(cascade = {CascadeType.ALL})

	private List <Bookings> bookings;

	public Flightdetails() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Flightdetails(int flightNo, String flightName, String fromCity, String toCity, String travelDate,
			double fair, List<Bookings> bookings) {
		super();
		FlightNo = flightNo;
		FlightName = flightName;
		FromCity = fromCity;
		ToCity = toCity;
		TravelDate = travelDate;
		Fair = fair;
		this.bookings = bookings;
	}

	public Flightdetails(String flightName, String fromCity, String toCity, String travelDate, double fair) {
		super();
		FlightName = flightName;
		FromCity = fromCity;
		ToCity = toCity;
		TravelDate = travelDate;
		Fair = fair;
	}

	public int getFlightNo() {
		return FlightNo;
	}

	public void setFlightNo(int flightNo) {
		FlightNo = flightNo;
	}

	public String getFlightName() {
		return FlightName;
	}

	public void setFlightName(String flightName) {
		FlightName = flightName;
	}

	public String getFromCity() {
		return FromCity;
	}

	public void setFromCity(String fromCity) {
		FromCity = fromCity;
	}

	public String getToCity() {
		return ToCity;
	}

	public void setToCity(String toCity) {
		ToCity = toCity;
	}

	public String getTravelDate() {
		return TravelDate;
	}

	public void setTravelDate(String travelDate) {
		TravelDate = travelDate;
	}

	public double getFair() {
		return Fair;
	}

	public void setFair(double fair) {
		Fair = fair;
	}

	public List<Bookings> getBookings() {
		return bookings;
	}

	public void setBookings(List<Bookings> bookings) {
		this.bookings = bookings;
	}

	@Override
	public String toString() {
		return "Flightdetails [FlightNo=" + FlightNo + ", FlightName=" + FlightName + ", FromCity=" + FromCity
				+ ", ToCity=" + ToCity + ", TravelDate=" + TravelDate + ", Fair=" + Fair + ", bookings=" + bookings
				+ "]";
	}
	
}