package com.Allservlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.persistence.Query;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.Entities.Flightdetails;
import com.HibernateConnection.FactoryProvider;


@WebServlet("/SearchFlight")
public class SearchFlight extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		response.setContentType("Text/html");
		PrintWriter out = response.getWriter();
				
		String FromCity1 = request.getParameter("FromCity");
		String ToCity = request.getParameter("ToCity");
		String TravelDate = request.getParameter("TravelDate");
		
		/*
		 * out.println(FromCity); out.println(ToCity); out.println(TravelDate);
		 */
		Flightdetails f = new Flightdetails();	
		Session s = FactoryProvider.getFactory().openSession();
		
		// This is HQL
		Query q = s.createQuery("from Flightdetails as f where f.FromCity=:x AND f.ToCity=:n AND f.TravelDate=:d");
		q.setParameter("x",FromCity1);
		q.setParameter("n",ToCity);
		q.setParameter("d",TravelDate);
		// SetParameter 
		List<Flightdetails> list = q.getResultList();
		
		for (Flightdetails U : list) {
			out.print("<tr>");
			out.print("<td>" + U.getFlightNo() + "</td>");
			out.println("<td>" + U.getFlightName() + "</td>");
			out.println("<td>" + U.getFromCity() + "</td>");
			out.println("<td>" + U.getToCity() + "</td>");
			out.println("<td>" + U.getFair() + "</td>");
			out.println("<td><a href='Addcustomer?FlightNo="+U.getFlightNo() + "'>Bookit</a> </td>");
			out.print("</tr>");
		}
		
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
