package com.Entities;

import java.util.Date;


import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;

@Entity
public class Bookings {
	
	@Override
	public String toString() {
		return "Bookings [PNR=" + PNR + ", PassangerName=" + PassangerName + ", Gender=" + Gender + ", Email=" + Email
				+ ", Ticketstatus=" + Ticketstatus + ", bookingDate=" + bookingDate + ", flightdetails=" + flightdetails
				+ "]";
	}

	public int getPNR() {
		return PNR;
	}

	public void setPNR(int pNR) {
		PNR = pNR;
	}

	public String getPassangerName() {
		return PassangerName;
	}

	public void setPassangerName(String passangerName) {
		PassangerName = passangerName;
	}

	public String getGender() {
		return Gender;
	}

	public void setGender(String gender) {
		Gender = gender;
	}

	public String getEmail() {
		return Email;
	}

	public void setEmail(String email) {
		Email = email;
	}

	public String getTicketstatus() {
		return Ticketstatus;
	}

	public void setTicketstatus(String ticketstatus) {
		Ticketstatus = ticketstatus;
	}

	public Date getBookingDate() {
		return bookingDate;
	}

	public void setBookingDate(Date bookingDate) {
		this.bookingDate = bookingDate;
	}

	public Flightdetails getFlightdetails() {
		return flightdetails;
	}

	public void setFlightdetails(Flightdetails flightdetails) {
		this.flightdetails = flightdetails;
	}

	public Bookings(String passangerName, String gender, String email, String ticketstatus, Date bookingDate,
			Flightdetails flightdetails) {
		super();
		PassangerName = passangerName;
		Gender = gender;
		Email = email;
		Ticketstatus = ticketstatus;
		this.bookingDate = bookingDate;
		this.flightdetails = flightdetails;
	}

	public Bookings(int pNR, String passangerName, String gender, String email, String ticketstatus, Date bookingDate,
			Flightdetails flightdetails) {
		super();
		PNR = pNR;
		PassangerName = passangerName;
		Gender = gender;
		Email = email;
		Ticketstatus = ticketstatus;
		this.bookingDate = bookingDate;
		this.flightdetails = flightdetails;
	}
	public Bookings(String passangerName, String gender, String email, String ticketstatus, Date bookingDate
			) {
		super();
		
		PassangerName = passangerName;
		Gender = gender;
		Email = email;
		Ticketstatus = ticketstatus;
		this.bookingDate = bookingDate;
		
	}

	public Bookings() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private int PNR;
	private String PassangerName;
	private String Gender;
	private String Email;
	private String Ticketstatus;
	private Date bookingDate;
	
	@OneToOne
	private Flightdetails flightdetails;

	
	

}
